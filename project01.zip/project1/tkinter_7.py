
from tkinter import *

win = Tk()
win.title("Calculator")
win.config(bg="#9cbb44")
win.geometry("500x700")

i = 0
math = ""

ent = Entry(win, width=56, borderwidth=5)
ent.place(x=10, y=10)

def click(num):
    res = ent.get()
    ent.delete(0, END)
    ent.insert(0, str(res) + str(num))

buttons = [
    (1, 10, 60), (2, 90, 60), (3, 180, 60),
    (4, 10, 120), (5, 90, 120), (6, 180, 120),
    (7, 10, 180), (8, 90, 180), (9, 180, 180),
]


for val, x, y in buttons:
    Button(win, text=str(val), width=12, bg="#ccd1cc", command=lambda v=val: click(v)).place(x=x, y=y)

def click0():
    res = ent.get()
    if res == "":
        ent.insert(END, "0")
    elif res != "0":
        ent.insert(END, "0")

button0 = Button(win, text="0", width=12, bg="#ccd1cc", command=click0)
button0.place(x=10, y=240)

def dot():
    res = ent.get()
    if res == "":
        ent.insert(END, ".")
    else:
        tokens = res.split()
        if tokens and '.' not in tokens[-1]:
            ent.insert(END, '.')



Button(win, text=".", width=12, bg="#ccd1cc", command=dot).place(x=90, y=240)

def add():
    global i, math
    try:
        i = float(ent.get())
        math = "addition"
        ent.delete(0, END)
    except:
        ent.delete(0, END)
        ent.insert(0, "0")

Button(win, text="+", width=12, bg="#ccd1cc", command=add).place(x=180, y=240)

def sub():
    global i, math
    try:
        i = float(ent.get())
        math = "subtraction"
        ent.delete(0, END)
    except:
        ent.delete(0, END)
        ent.insert(0, "0")

Button(win, text="-", width=12, bg="#ccd1cc", command=sub).place(x=10, y=300)

def mul():
    global i, math
    try:
        i = float(ent.get())
        math = "multiplication"
        ent.delete(0, END)
    except:
        ent.delete(0, END)
        ent.insert(0, "0")

Button(win, text="x", width=12, bg="#ccd1cc", command=mul).place(x=90, y=300)

def div():
    global i, math
    try:
        i = float(ent.get())
        math = "division"
        ent.delete(0, END)
    except:
        ent.delete(0, END)
        ent.insert(0, "0")

Button(win, text="/", width=12, bg="#ccd1cc", command=div).place(x=180, y=300)

def clear():
    le=len(ent.get())
    if le==1:
        ent.insert(0,"0")
    ent.delete(0, END)


Button(win, text="clear", width=12, bg="#ccd1cc", command=clear).place(x=10, y=360)

def equal():
    try:
        n2 = float(ent.get())
        ent.delete(0, END)
        if math == "addition":
            ent.insert(0, i + n2)
        elif math == "subtraction":
            ent.insert(0, i - n2)
        elif math == "multiplication":
            ent.insert(0, i * n2)
        elif math == "division":
            if n2 == 0:
                ent.insert(0, "Cannot divide by 0")
            else:
                ent.insert(0, i / n2)
    except:
        ent.insert(0, "0")

Button(win, text="=", width=12, bg="#ccd1cc", command=equal).place(x=180, y=360)

def back_del():
    lent= len(ent.get())
    ent.delete(lent-1)
    if lent==1:
        ent.insert(0,"0")


Button(win, text="del", width=12, bg="#ccd1cc", command=back_del).place(x=90, y=360)



win.mainloop()

